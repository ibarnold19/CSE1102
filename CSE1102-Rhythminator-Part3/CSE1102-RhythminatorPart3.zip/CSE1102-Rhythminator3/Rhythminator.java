import javax.swing.SwingUtilities;
import model.Clock;
import model.Model;
import model.Sound;
import view.View;
import controller.Controller;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Rhythminator{

	private static final int NUM_TRACKS = 6;
	private static final int NUM_BEATS  = 16;

	public static void main(String[] args){

		Sound.scanSoundDir("sounds");
		Sound s1 = new Sound("CymbalCrash1");

		for(int n=0; n<4; n++){

			s1.play();

			try
			{
				Thread.sleep(250);

			}

			catch(InterruptedException e){

				e.printStackTrace();

			}

		}

		// In order to use Swing graphics effectively, the program should be started
		// running in a concurrent thread controlled by Swing. This is how you do it:

		SwingUtilities.invokeLater(new Runnable(){

			@Override
			public void run(){

				Rhythminator._main();

			}

		});

	}

	// I put all the interesting stuff in a separate method here so that you don't
	// have to keep looking at the Swing threading stuff in the main method above.

	private static void _main(){

		Sound.scanSoundDir();
		Model model = new Model(NUM_TRACKS, NUM_BEATS);
		Clock clock = model.getClock();
		Controller controller = new Controller(clock, model);
		View view = new View(controller, NUM_TRACKS, NUM_BEATS);
		controller.setView(view);

	}

}
