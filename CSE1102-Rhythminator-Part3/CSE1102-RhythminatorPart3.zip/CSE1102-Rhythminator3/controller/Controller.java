package controller;

import gui.Button;
import gui.Dialog;
import message.ISubscriber;
import message.Message;
import model.Clock;
import model.Model;
import view.NoteSquare;
import view.View;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Controller implements ISubscriber
{

	private Model _model;
	private Clock _clock;
	private View  _view;

	public Controller(Clock clock, Model model)
	{

		this._model = model;
		this._clock = clock;
		clock.subscribe(this);

	}

	public void buttonPressed(Button button)
	{
		if(button.getText().equals("Save"))
			_buttonSave();
		else if(button.getText().equals("Load"))
			_buttonLoad();
		else if(button.getText().equals("Play"))
		{
			this._model.setNote(0, 1, false);
			this._model.startPlaying();
			System.out.println("Controller.buttonPressed got Play button");
		}
		else if(button.getText().equals("Stop"))
		{
			this._model.stopPlaying();
			this._view.clearBeatNumbers();
			System.out.println("Controller.buttonPressed got Stop button");
		}
		else if(button.getText().equals("Quit"))
			_buttonQuit();
		else
			System.out.println("Controller.buttonPressed " + button + " pressed");
	}

	private void _buttonQuit()
	{
		if(Dialog.askYesNo("Exiting program", "Really quit?"))
			System.exit(0);
	}

	private void _buttonLoad()
	{
		System.out.println("Load Button Pressed");
	}

	private void _buttonSave()
	{

		System.out.println("Save Button Pressed");
		System.out.println("Rhythm name: " + this._view.getHead().getFile());
		long tempo = 15000/(this._model.getClock().getDelay());
		System.out.println("Tempo: " + tempo);

	}

	public void keyPressed(int keyCode)
	{
		System.out.println("Controller.keyPressed " + keyCode);
	}

	public void keyReleased(int keyCode)
	{
		System.out.println("Controller.keyReleased " + keyCode);
	}

	public void keyTyped(char keyChar)
	{
		System.out.println("Controller.keyTyped '" + keyChar + "'");
	}

	public void noteSquareClicked(NoteSquare noteSquare) {

		int trackNum = noteSquare.getTrack();
		int beatNum = noteSquare.getBeat();
		int value = noteSquare.getValue();

		if(value == 0) {


			_model.setNote(trackNum, beatNum, false);

		} else {


			_model.setNote(trackNum, beatNum, true);

		}

		System.out.println("Controller.noteSquareClicked " + noteSquare);

	}

	@Override
	public void notify(Message message)
	{
		this._view.setBeatNumber(this._model.getBeatNumber() - 1);
		System.out.println("Beat: " + this._model.getBeatNumber());
		System.out.println("Controller.notify " + message);
	}

	public void soundNameSelected(int trackNumber, String soundName)
	{

		this._model.setSoundName(trackNumber, soundName);
		this._view.setSoundName(trackNumber, soundName);
		System.out.println("Controller.soundNameSelected for track " + trackNumber + ": " + soundName);
	}

	public void setView(View view)
	{
		_view = view;
	}

	public void sliderChange(String name, int _value)
	{
		this._clock.setDelay(15000/_value);
		System.out.println("Controller.sliderChange " + name + " = " + _value);
	}

}
