package view;
import javax.swing.JPanel;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class BeatNumbers extends JPanel {

	private static final long serialVersionUID = 1L;
	private BeatNumberSquare[] _beats;

	public BeatNumbers(int beat){

		this.setLayout(null);

		this._beats = new BeatNumberSquare[beat];

		int n = 0;

		for(int i = 0; i < beat; i++){

			BeatNumberSquare beats = new BeatNumberSquare(i + 1);
			this.add(beats);

			_beats[i] = beats;
			beats.setLocation(n, 0);

			if (i < beat - 1){

				n += NoteSquare.SIZE + Tracks.GAP_SIZE;

			}

		}

		this.setSize((beat * NoteSquare.SIZE) + (beat * Tracks.GAP_SIZE), NoteSquare.SIZE);

	}

	public void setBeatNumber(int beat){

		for(int i = 0; i < this._beats.length; i++){

			if(_beats[i].getState() == true){

				_beats[i].setState(false);

			} 

		}

		_beats[beat].setState(true);

	}

	public void clear(){

		for(int i = 0; i < this._beats.length; i++){

			if(_beats[i].getState() == true){

				_beats[i].setState(false);

			}

		}

	}

}
