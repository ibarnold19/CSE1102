package view;
import gui.NumberSlider;
import controller.Controller;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class View {


	private BeatNumbers _numBeats;
	private SoundBank _sounds;
	private Header _head;
	private Tracks _track;
	private NumberSlider _slider;

	public View(Controller controller, int numTracks, int numBeats){

		Window window = new Window(controller, "Rhythminator");
		window.setSize(900, 500);
		Header head = new Header(controller);
		this._head = head;
		head.setLocation(10, 10);
		window.add(head);
		SoundBank sounds = new SoundBank(controller, numTracks);
		this._sounds = sounds;
		sounds.setLocation(10, 60);
		window.add(sounds);
		Tracks tracks = new Tracks(controller, numTracks, numBeats);
		this._track = tracks;
		tracks.setLocation(150, 60);
		window.add(tracks);
		ControlButtons controls = new ControlButtons(controller);
		controls.setLocation(10, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 30);
		window.add(controls);
		BeatNumbers beatNum = new BeatNumbers(numBeats);
		this._numBeats = beatNum;
		beatNum.setLocation(150, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 30);
		window.add(beatNum);
		NumberSlider slider = new NumberSlider(controller, null, 10, 200, 25);
		slider.setLocation(150, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 70);
		window.add(slider);
		window.setVisible(true);

	}

	public void setBeatNumber(int beat){

		this._numBeats.setBeatNumber(beat);

	}

	public void clearBeatNumbers(){

		this._numBeats.clear();

	}

	public void setSoundName(int track, String name){

		this._sounds.setSoundName(track, name);

	}

	public Header getHead() {
		return _head;
	}

	public Tracks getTrack() {
		return _track;
	}

	public NumberSlider getSlider() {
		return _slider;
	}

	public BeatNumbers getNumBeats(){

		return this._numBeats;

	}

}
