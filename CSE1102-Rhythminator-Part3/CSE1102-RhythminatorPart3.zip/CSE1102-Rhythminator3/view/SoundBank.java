package view;

import javax.swing.JPanel;
import controller.Controller;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class SoundBank extends JPanel {

	private static final long serialVersionUID = 6249914173769272977L;
	private SoundNameBox[] _soundNameBoxes;

	public SoundBank(Controller aController, int numTracks) {
		
		setLayout(null);
		int width = 0;
		
		
		_soundNameBoxes = new SoundNameBox[numTracks];
		
		
		int y = 0;  
		
		for (int i=0; i < numTracks; i++) {
			SoundNameBox soundNameBox = new SoundNameBox(aController, i+1);
			soundNameBox.setLocation(0, y);
			_soundNameBoxes[i] = soundNameBox;
			_soundNameBoxes[i].setBackground(Colors.NOTESQUARE_OFF);
	
			
			y += Tracks.GAP_SIZE + soundNameBox.getSize().getHeight();
			
		
			add(soundNameBox);
		}
		
		
		if (_soundNameBoxes[0] != null) 
			width = (int) _soundNameBoxes[0].getSize().getWidth();
		
		setSize(width, y);
	}
	
	public void setSoundName(int trackNum, String soundName) {
		_soundNameBoxes[trackNum - 1].setText(soundName);
	}
}
