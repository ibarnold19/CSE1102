package model;

import message.ISubscriber;
import message.Sequencer;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

@SuppressWarnings("unused")

public class Model{

	public int _numTracks;
	public int _numBeats;
	private SoundBank _soundBank;
	private Sequencer _sequencer;
	private Chord[] _chords;
	private Clock _clock;

	/**
	 * The model sets up the clock.
	 * Most of the work of running the application happens in the clock.
	 * @param numTracks
	 * @param numBeats
	 */
	public Model(int numTracks, int numBeats)
	{
		this._numTracks = numTracks;
		this._numBeats = numBeats;

		Sequencer sequencer = new Sequencer(numBeats);
		this._sequencer = sequencer;
		SoundBank soundbank = new SoundBank(new Sound[numTracks]);
		this._soundBank = soundbank;
		Chord[] chords = new Chord[numBeats];
		this._chords = chords;


		for(int i = 0; i < this._chords.length; i++){

			chords[i] = new Chord(soundbank, numTracks);
			sequencer.subscribe(chords[i]);

		}

		Clock clock = new Clock();
		this._clock = clock;

		clock.subscribe(sequencer);

	}

	public int getBeatNumber()
	{
		return _sequencer.getStepNumber();
	}

	public Clock getClock()
	{
		return _clock;
	}

	public int getTracks(){

		return this._numTracks;

	}

	public void startPlaying()
	{
		this._clock.start();
	}

	public void stopPlaying()
	{
		this._clock.stop();
		this._sequencer.reset();
	}

	public void setNote(int trackNum, int beatNum, boolean value)
	{  

		this._chords[beatNum].setNote(trackNum, value);  

	}

	public void setSoundName(int trackNum, String soundName)
	{

		Sound sound1 = new Sound(soundName);

		this._soundBank.setSound(trackNum - 1, sound1);

	}

	public SoundBank getSoundBank(){

		return this._soundBank;

	}

}
