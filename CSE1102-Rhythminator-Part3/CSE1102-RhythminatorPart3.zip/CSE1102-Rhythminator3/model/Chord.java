package model;

import message.ISubscriber;
import message.Message;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Chord implements ISubscriber{

	private SoundBank _soundBank;
	private boolean[] _notes;

	public Chord(SoundBank soundBank, int numNotes){

		_soundBank = soundBank;
		_notes = new boolean[numNotes];

	}

	@Override
	public void notify(Message message){

		this.play();

	}

	public void play(){

		_soundBank.play(_notes);

	}

	public void setNote(int noteNumber, boolean noteValue){

		_notes[noteNumber] = noteValue;

	}

}
