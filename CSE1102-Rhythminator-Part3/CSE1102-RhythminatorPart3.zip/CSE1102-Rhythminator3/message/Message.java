package message;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Message{

	private IPublisher _publisher;

	public Message(IPublisher publisher){

		_publisher = publisher;

	}

	public IPublisher getPublisher(){

		return _publisher;

	}

}
