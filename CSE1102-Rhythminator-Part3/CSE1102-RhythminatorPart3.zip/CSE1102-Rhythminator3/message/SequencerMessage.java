package message;

//Rhythminator Part 3
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//5/2/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class SequencerMessage extends Message{

	private int _stepNumber;

	public SequencerMessage(IPublisher publisher, int stepNumber){

		super(publisher);
		_stepNumber = stepNumber;

	}

	public int getStepNumber(){

		return _stepNumber;

	}

}
