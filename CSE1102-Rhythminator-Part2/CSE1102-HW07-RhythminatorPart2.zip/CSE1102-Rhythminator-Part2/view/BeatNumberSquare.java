package view;
import gui.Box;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class BeatNumberSquare extends Box {

	private static final long serialVersionUID = 1L;
	private int _beat;
	private boolean _state;

	public BeatNumberSquare(int beat){

		super();
		this._beat = beat;
		this._state = false;

		setText(Integer.toString(beat));
		setForeground(Colors.BEATNUMBER_OFF_FG);
		setBackground(Colors.BEATNUMBER_OFF_BG);
		setSize(NoteSquare.SIZE, NoteSquare.SIZE);

	}

	public boolean getState(){

		return this._state;

	}

	public int getBeat(){

		return this._beat;

	}


	public void setState(boolean state) {

		this._state = state;

		if(this._state == true){

			setForeground(Colors.BEATNUMBER_ON_FG);
			setBackground(Colors.BEATNUMBER_ON_BG);

		} else if(this._state == false){

			setForeground(Colors.BEATNUMBER_OFF_FG);
			setBackground(Colors.BEATNUMBER_OFF_BG);

		}

		invalidate();

	}

}
