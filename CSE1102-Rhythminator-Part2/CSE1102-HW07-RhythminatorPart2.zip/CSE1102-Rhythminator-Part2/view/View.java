package view;
import gui.NumberSlider;
import controller.Controller;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class View {

	public View(Controller controller, int numTracks, int numBeats){

		Window window = new Window(controller, "Rhythminator");
		window.setSize(900, 500);
		Header head = new Header(controller);
		head.setLocation(10, 10);
		window.add(head);
		SoundBank sounds = new SoundBank(controller, numTracks);
		sounds.setLocation(10, 60);
		window.add(sounds);
		Tracks tracks = new Tracks(controller, numTracks, numBeats);
		tracks.setLocation(150, 60);
		window.add(tracks);
		ControlButtons controls = new ControlButtons(controller);
		controls.setLocation(10, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 30);
		window.add(controls);
		BeatNumbers beatNum = new BeatNumbers(numBeats);
		beatNum.setLocation(150, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 30);
		window.add(beatNum);
		NumberSlider slider = new NumberSlider(controller, null, 0, 100, 25);
		slider.setLocation(150, numTracks * NoteSquare.SIZE + 30 + numTracks * Tracks.GAP_SIZE + 70);
		window.add(slider);
		window.setVisible(true);

	}

}
