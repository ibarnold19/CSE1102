package view;
import javax.swing.JPanel;
import controller.Controller;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Tracks extends JPanel{

	private static final long serialVersionUID = 1L;
	public static final int GAP_SIZE = 10;	

	public Tracks(Controller controller, int tracks, int beats){

		this.setLayout(null);

		NoteSquare [][] squares = new NoteSquare[tracks][beats];

		int n = 0;
		int m = 0;

		for (int i = 0; i < tracks; i++){

			for (int j = 0; j < beats; j++){

				squares[i][j] = new NoteSquare(controller, i, j);
				this.add(squares[i][j]);
				squares[i][j].setLocation(n, m);

				if (j < beats - 1){

					n += NoteSquare.SIZE + GAP_SIZE;

				} else {

					m += NoteSquare.SIZE + GAP_SIZE;
					n = 0;

				}
			}
		}

		setSize((beats * NoteSquare.SIZE) + (beats * GAP_SIZE), ((tracks * NoteSquare.SIZE) + (tracks * GAP_SIZE)));

	}

}
