package view;
import java.awt.event.MouseEvent;
import controller.Controller;
import gui.Box;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class NoteSquare extends Box{

	private static final long serialVersionUID = 1L;
	public static final int SIZE = 30;
	private Controller _controller;
	private int _track;
	private int _beat;
	private int _value;

	public NoteSquare(Controller controller, int track, int beat){

		super();
		this._controller = controller;
		this._track = track;
		this._beat = beat;
		this._value = 0;

		setSize(SIZE, SIZE);
		setBackground(Colors.NOTESQUARE_OFF);

	}

	public int getTrack(){

		return this._track;

	}

	public int getBeat(){

		return this._beat;

	}

	public int getValue(){

		return this._value;

	}

	public void setValue(int value){

		this._value = value;

		if(this._value == 0){

			this.setBackground(Colors.NOTESQUARE_OFF);

		} else if(this._value == 1){

			this.setBackground(Colors.NOTESQUARE_ON);

		}

		repaint();

	}

	@Override
	public void mousePressed(MouseEvent mev){

		if(this.getValue() == 0){

			this.setValue(1);

		} else if(this.getValue() == 1) {

			this.setValue(0);

		}

		this._controller.noteSquareClicked(this);

	}

	@Override
	public String toString(){

		return "NoteSquare(track = " + this.getTrack() + ", beat = " + this.getBeat() + ")";

	}

}
