package view;
import java.awt.event.MouseEvent;
import controller.Controller;
import gui.Box;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class SoundNameBox extends Box{

	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 130;
	public static final int HEIGHT = 30;
	private Controller _controller;
	private int _track;

	public SoundNameBox(Controller controller, int track){

		super();
		this._track = track;
		this._controller = controller;

		setSize(WIDTH, HEIGHT);

	}

	@Override
	public void mousePressed(MouseEvent mev){

		String text = getText();
		SoundChooser.open(_controller, _track, text);

	}

}
