package view;
import javax.swing.JPanel;
import controller.Controller;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class SoundBank extends JPanel{

	private static final long serialVersionUID = 1L;
	SoundNameBox[] _soundName;

	public SoundBank(Controller controller, int tracks){

		this.setLayout(null);

		SoundNameBox[] _soundName = new SoundNameBox[tracks];

		int n = 0;

		for(int i = 0; i < tracks; i++){

			_soundName[i] = new SoundNameBox(controller, i);
			this.add(_soundName[i]);
			_soundName[i].setBackground(Colors.NOTESQUARE_OFF);
			_soundName[i].setLocation(0, n);

			if(i < tracks - 1){

				n = n + Tracks.GAP_SIZE + SoundNameBox.HEIGHT;

			}

		}

		
		this.setSize(130, (tracks * Tracks.GAP_SIZE) + (tracks * SoundNameBox.HEIGHT));

	}

	public void setSoundName(int track, String name){

		this._soundName[track].setText(name);

	}

}
