package view;
import javax.swing.JPanel;
import controller.Controller;
import gui.Button;
import gui.TextBox;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Header extends JPanel{

	private static final long serialVersionUID = 1L;
	private TextBox _text;

	public Header(Controller controller){

		setLayout(null);

		TextBox text = new TextBox("Unnamed", "Enter a new name: ", "Change name");
		this._text = text;
		text.setSize(200, 30);
		text.setLocation(0, 0);
		text.setBackground(Colors.NOTESQUARE_OFF);

		Button load = new Button(controller, "Load");
		load.setSize(60, 30);
		load.setLocation(210, 0);

		Button save = new Button(controller, "Save");
		save.setSize(60, 30);
		save.setLocation(280, 0);

		Button quit = new Button(controller, "Quit");
		quit.setSize(60, 30);
		quit.setLocation(380, 0);

		this.setSize(440, 30);
		this.add(text);
		this.add(load);
		this.add(save);
		this.add(quit);

	}

	public String getFile(){

		String text = this._text.getText();

		return text;

	}


}
