package view;
import javax.swing.JPanel;
import controller.Controller;
import gui.Button;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class ControlButtons extends JPanel {

	private static final long serialVersionUID = 1L;
	
	public ControlButtons(Controller controller){
		
		setLayout(null);
		Button play = new Button(controller, "Play");
		Button stop = new Button(controller, "Stop");
		add(play);
		add(stop);
		
		play.setSize(60, 30);
		stop.setSize(60, 30);
		play.setLocation(0, 0);
		stop.setLocation(70, 0);
		setSize(130, 30);
		
	}

}
