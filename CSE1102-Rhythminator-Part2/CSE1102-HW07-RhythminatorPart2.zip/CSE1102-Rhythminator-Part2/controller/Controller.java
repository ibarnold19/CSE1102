package controller;
import gui.Button;
import view.NoteSquare;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Controller{

	public Controller(){}

	public void keyPressed(int keyCode){

		//System.out.println("Controller.keyPressed " + keyCode);

	}

	public void keyReleased(int keyCode){

		//System.out.println("Controller.keyReleased " + keyCode);

	}

	public void keyTyped(char keyChar){

		//System.out.println("Controller.keyTyped '" + keyChar + "'");

	}

	public void soundNameSelected(int trackNumber, String soundName){

		System.out.println("Sound " + soundName + " selected for track " + trackNumber);

	}

	public void buttonPressed(Button button) {

		button.toString();
		System.out.println("Button pressed");

	}

	public void sliderChange(String name, int value) {

		System.out.println("Slider " + name + " changed to " + value);

	}

	public void noteSquareClicked(NoteSquare square){

		System.out.println("NoteSquare clicked: " + square);

	}

}
