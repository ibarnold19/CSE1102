package gui;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import controller.Controller;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class NumberSlider extends JPanel implements ChangeListener {

	private static final long serialVersionUID = 1L;
	private Controller _controller;
	private String _name;
	private Box _box;
	private JSlider _slider;

	public NumberSlider(Controller controller, String name, int min, int max, int value){

		this.setLayout(null);

		this._name = name;
		this._controller = controller;

		Box box = new Box();
		this._box = box;

		box.setLocation(0, 0);
		box.setSize(40, 30);
		box.setText(Integer.toString(value));
		box.setBackground(Colors.WINDOW_BG);
		add(box);

		JSlider slider = new JSlider(JSlider.HORIZONTAL, min, max, value);
		this._slider = slider;

		slider.setLocation(box.getWidth(), 0);
		slider.setSize(200, 30);
		add(slider);

		setSize(box.getWidth() + slider.getWidth(), 30);

		slider.addChangeListener(this);
		slider.setFocusable(false);

	}

	@Override
	public void stateChanged(ChangeEvent arg0) {

		_box.setText(Integer.toString(_slider.getValue()));

		_controller.sliderChange(_name, _slider.getValue());

	}

}
