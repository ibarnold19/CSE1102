package gui;
import java.awt.event.MouseEvent;
import controller.Controller;

//Rhythminator Part 2
//CSE1102 Project 07, Spring 2016
//Bryan Arnold
//4/24/16
//TA: Zigeng Wang
//Section: 51
//Instructor: Jeffrey A. Meunier

public class Button extends Box {

	private static final long serialVersionUID = 1L;
	private Controller _controller;

	public Button(Controller controller, String text){

		super(text);
		this._controller = controller;

	}

	@Override
	public String toString(){

		return "Button(" + getText() + ")";

	}

	@Override
	public void mousePressed(MouseEvent mev){

		this._controller.buttonPressed(this);

	}

}
